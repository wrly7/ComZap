<!DOCTYPE html>
<html>
<head>
    <title>Bem-vindo ao ComZap</title>
</head>
<body>
    <h1>Instalação bem-sucedida!</h1>
</body>
</html>